<?php
	$link=mysqli_connect("localhost:3307","root","","art_gallery");
	if(mysqli_connect_error())
	{
		echo "Connection error".mysqli_connect_error();
		exit;
	}
	
?>